# TODO!

[x] complete finger
[/] match api
[/] focus handler (this comes for free from loop)
[x] animation frame handler
[ ] node-ify lib
[ ] make tests run under node context
[ ] add inline docs
[ ] connect/disconnect events