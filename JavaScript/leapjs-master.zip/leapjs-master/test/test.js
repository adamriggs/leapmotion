assert = require('chai').assert
Leap = require('../lib').Leap
fakeHand = require('./common').fakeHand
fakeFrame = require('./common').fakeFrame
fakeFinger = require('./common').fakeFinger
fakeController = require('./common').fakeController
fakeGesture = require('./common').fakeGesture
_ = require("underscore")

